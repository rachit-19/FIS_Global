package com.example.eureka.commenteurekaclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommenteurekaclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
