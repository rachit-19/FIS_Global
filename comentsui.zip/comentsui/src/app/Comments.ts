export class Comments{
    cid : number = 0;
    commenter : string ="";
    pid : number = 0;
    comment : string ="";
}