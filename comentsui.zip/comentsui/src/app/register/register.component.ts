import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommentService } from '../comment.service';
import { Comments } from '../Comments';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  cid : any;
  pid=0;
  commenter="";
  comment="";

constructor (private service: CommentService, private router:Router) { }
  formdata : FormGroup = new FormGroup({
    cid: new FormControl(null, [
      Validators.required,
      Validators.minLength(3)      
    ])
  });

  ngOnInit(): void {
  }
  insertComment(){

    let cmt : Comments = {
      "cid":this.cid,
      "commenter":this.commenter,
      "pid":this.pid,
      "comment":this.comment
       }
    //console.log(this.cid+" "+this.commenter+" "+this.pid+" "+this.comment);
      this.service.registerComment(cmt);
      this.router.navigate(['display'])
  .then(() => {
    window.location.reload();
  });

  }

}
