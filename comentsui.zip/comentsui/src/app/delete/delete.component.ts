import { Component, OnInit } from '@angular/core';
import { CommentService } from '../comment.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
  cid=0;
  constructor(private service : CommentService) { }

  ngOnInit(): void {
  }
  deleteComment(){
    this.service.deleteComment(this.cid);
  }
}
