import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  username = "admin";
  passwd = "admin";
  constructor(private router : Router){ }
  validate(){
    if(this.username=="admin" && this.passwd=="admin"){
      console.log("Access granted");
      this.router.navigateByUrl("menu");
    }
    else{
      console.log("Access Denied");
      this.router.navigateByUrl("register");
    }
  }
}
