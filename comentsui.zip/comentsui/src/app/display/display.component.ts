import { Component, OnInit } from '@angular/core';
import { CommentService } from '../comment.service';
import { Comments } from '../Comments';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  constructor(private service: CommentService) { }
  cmts:any;
  cid = 0;
  data: any;
  ngOnInit(): void {
    this.service.getAllComments()
    .subscribe( response =>{
      this.cmts=response;
      console.log(response);
    }
    );
    console.log(this.cmts);
  }
  deleteComment(){
    this.service.deleteComment(this.cid)
    .subscribe(response=>{ this.data = response,
    console.log(this.data)
  }
    )};
  }

